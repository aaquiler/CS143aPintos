#ifndef DEVICES_VGA_H
#define DEVICES_VGA_H

void vga_putc (int);

#endif /* devices/vga.h */
